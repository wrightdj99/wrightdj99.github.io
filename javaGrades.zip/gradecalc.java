
package firstthing;
import java.time.Year;
import java.util.*;


/**
 * gradecalc
 */

public class gradecalc {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Scanner goag = new Scanner(System.in);
        int homework[] = new int[10];
        int i;
        int total = 0, avg;

        
        System.out.println("Hello there! I hope you had a nice quarter. By inputting the grades for your 10 homework assignments, you can get your final grade for the class!");

        for(i = 0; i < 10; i++){
                System.out.println("Enter your grade for Lab " + (i+1) + ": ");
                homework[i] = input.nextInt();
                total = total + homework[i];
            
        }
        input.close();
        avg = total/10;
        System.out.println("Student grade is: ");
        if(avg>=90){
            System.out.println("A");
        }
        else if(avg>=80 && avg<89){
            System.out.println("B");
        }
        else if(avg>=70 && avg<79){
            System.out.println("C");
        }
        else{
            System.out.println("D");
        }

        System.out.println("\n");

    }
}
    