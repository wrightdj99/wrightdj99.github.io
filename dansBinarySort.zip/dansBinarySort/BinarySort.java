/*This is Binary Insertion Sort!

With binary sort, like binary search, we can minimize the amount of searches needed to sort numbers by
just dividing the array or list in half over and over and over again until we find the correct place to insert
a new value.*/

//We need these
import java.util.Arrays;
import java.util.Random;

public class BinarySort{
    
    //This is a helper that lets us add new integers into an array.
    private static int[] append(int[] arr, int element){
        //First, we need to make a new array that is the old array + 1 
        //in terms of space
        int[] array = new int[arr.length + 1];
        //arraycopy is a method in util arrays that lets us copy array content
        //over and back from one place to another.
        System.arraycopy(arr, 0, array, 0, arr.length);
        array[arr.length] = element;
        return array;
    }

     public static void main(String []args){
        //Meme from Arthur that tests if our string output is working
        System.out.println("Are you having cake?");
        //Initialization of 4 arrays, with arr 1 being the hardest to sort
        int arr[] = {32, 44, 21, 75, 1240, 91, 33, 2};
        int arr1[] = {20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9,8, 7, 6, 5, 4, 3, 2, 1, 0};
        int arr2[] = {4234, 243, 1243, 234242, 23425, 234215, 12, 53, 64, 23, 5245, 5235, 78658, 634, 636, 346346, 3463, 543, 8954, 34};
        int arr3[] = {3, 29, 8743, 78, 111, 158, 189, 114, 909, 1000000, 1000001, 100002, 1000003, 1000004, 1000005, 10002};
        //Testing statements for insertion below
        /*
        arr = append(arr, 900);
        arr = append(arr, 1000000);
        arr = append(arr, 87953478);
        arr = append(arr, 848484);
        arr = append(arr, 90390);
        arr = append(arr, 77);
        arr1 = append(arr1, 90034);
        arr1 = append(arr1, 90035);
        arr1 = append(arr1, 90043);
        arr2 = append(arr2, 903);
        arr2 = append(arr2, 904);
        arr2 = append(arr2, 909);
        arr3 = append(arr, 8794384);
        arr3 = append(arr, 2);
        arr3 = append(arr, 888888888)
        */
        
        
        
        //calling our sort class on top of a sort method.
        new BinarySort().dansSort(arr);
        new BinarySort().dansSort(arr1);
        new BinarySort().dansSort(arr2);
        new BinarySort().dansSort(arr3);
        //For loop to make everything run to completion in the array
        for(int i = 1; i < arr.length; i++){
            System.out.println(arr[i]+ "(in array 1) \n");
        }
        
        for(int i = 1; i < arr1.length; i++){
            System.out.println(arr1[i]+ "(in  array 2) \n");
        }
        
        for(int i = 1; i < arr2.length; i++){
            System.out.println(arr2[i]+ "(in  array 3) \n");
        }
        
        for(int i = 1; i < arr3.length; i++){
            System.out.println(arr3[i]+ "(in  array 4) \n");
        }
        
        System.out.println("\n \n \n");
        System.out.println("---------");
        System.out.println("\n \n \n");
        
     }
     
     
     public static void dansSort(int array[]){
        //The actual sorting of our arrays won't be too hard, but for binary insertion sort
        //we will need a couple of unheard of lines of code. It will all be encased in a for loop
        for(int i = 1; i < array.length; i++){
            //Int curr stands for the current integer we are dealing with, but more importantly will 
            //also act as the place where each number eventually goes.
            int curr = array[i];
            //We're going to take the absolute value of our array length and blitz through it
            //to find the right place to place our various integers. array is for the default array
            //we're dealing with, starting at place 0, stopping at place i, and placing
            //said integer at curr. J is our "finder variable".
            int j = Math.abs(Arrays.binarySearch(array, 0, i, curr) + 1);
            //Because this is insertion, we will be shifting everything in the array 1 position right to
            //accound for the new number that's been inserted.
            System.arraycopy(array, j, array, j+1, i-j);
            //Finally, our integer is placed at index position j.
            array[j] = curr;
            
        } 
     }
     
     
}