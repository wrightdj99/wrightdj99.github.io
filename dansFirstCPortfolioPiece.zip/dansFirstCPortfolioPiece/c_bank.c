//This is a bank ATM program in C!
//1234 is the customer PIN. I don't know what he/she was
//thinking either... 

#include <stdio.h>

unsigned long amount = 1000, deposit, withdraw;
int choice, pin, k;
char transaction = 'y';

void main(){
	while(pin != 1234){
		printf("ENTER YOUR PIN NUMBER: ");
		scanf("%d", &pin);
		if(pin != 1234){printf("PLEASE ENTER YOUR PASSWORD\n");}

	}
	do{
		printf("*******Welcome to Moneybags ATM Service*******\n\n");
		printf("1. Check balance\n");
		printf("2. Withdraw Cash\n");
		printf("3. Deposit Cash\n");
		printf("4. Quit\n");
		printf("*************************************************\n");
		printf("Enter your choice: ");
		scanf("%d", &choice);
		switch(choice){
		case 1:
			printf("\n Your balance in $: %lu ", amount);
			break;
		case 2:
			printf("\n Enter the amount to withdraw: ");
			scanf("%lu", &withdraw);
			if(withdraw % 100 != 0){
				printf("\n Please enter the amount in 100s");
				
			}
			else if(withdraw >(amount - 50)){
				printf("\n Insufficient Balance");
			}
			else{
				amount = amount - withdraw;
				printf("\n\n Please collect your cash");
				printf("\n Your balance%lu", amount);
			}
			break;
		case 3:
			printf("\n Enter the amount to deposit: ");
			scanf("%lu", &deposit);
			amount = amount + deposit;
			printf("Your balance is %lu", amount);
			break;
		case 4:
			printf("\n Thank you for using Moneybags ATM service!");
			break;
		default:
			printf("\n Invalid choice");
		}
		printf("\n\n\n Do you want another transaction?(y/n)");
		fflush(stdin);
		scanf("%c", &transaction);
		if(transaction == 'n' || transaction == 'N'){
			k = 1;
		}
	} 
		while(!k);
			printf("\n\n\n Thanks for using Moneybags ATM service");

}
