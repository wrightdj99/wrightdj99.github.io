#Welcome to Dan's Super Snake Game!

#Part 1: Imports
import turtle
import time
import random

delay = 0.1
#Score Tally
score = 0
high_score = 0

#Part 2: Setting up screen
wnd = turtle.Screen()
wnd.title("Dan's Super Snake Game")
wnd.bgcolor("black")
wnd.setup(width=900, height=900)
wnd.tracer(0) #Turns off the screen updates

#Part 3: Creating Snake Head and Snake Food

#Head
head = turtle.Turtle()
head.speed(0)
head.shape("square")
head.color("red")
head.penup()
head.goto(0,0)
head.direction = "stop"

#Food
food = turtle.Turtle()
food.speed(0)
food.shape("circle")
food.color("blue")
food.penup()
food.goto(0,300)

#Scoring System (Pen)
pen = turtle.Turtle()
pen.speed(0)
pen.shape("square")
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 350)
pen.write("Score: 0 High Score: 0", align="center", font=("Comic Sans", 32, "normal"))

#Part 4: Creating the snake body
segments = []

#Part 4: Defining what is "up" vs "down"; These below are
#movement functions

def go_up():
    if head.direction != "down":
        head.direction = "up"

def go_down():
    if head.direction != "up":
        head.direction = "down"

def go_left():
    if head.direction != "right":
        head.direction = "left"

def go_right():
    if head.direction != "left":
        head.direction = "right"

def move():
    if head.direction == "up":
        y = head.ycor()
        head.sety(y + 20)

    if head.direction == "down":
        y = head.ycor()
        head.sety(y - 20)

    if head.direction == "left":
        x = head.xcor()
        head.setx(x - 20)

    if head.direction == "right":
        x = head.xcor()
        head.setx(x + 20)

# Keyboard bindings
wnd.listen()
wnd.onkeypress(go_up, "w")
wnd.onkeypress(go_down, "s")
wnd.onkeypress(go_left, "a")
wnd.onkeypress(go_right, "d")

while True:
    wnd.update()

    #Check for collision with border
    if head.xcor()>450 or head.xcor()<-450 or head.ycor()>450 or head.ycor()<-450:
        time.sleep(1)
        head.goto(0,0)
        head.direction = "stop"

        #Dealing with segment collision

        for segment in segments:
            segment.goto(1000, 1000)

        segments.clear()
        #Reset score
        score = 0

        #Reset Delay
        delay = 0.1

        #Update scoreboard
        pen.clear()
        pen.write("Score: {} High Score: {}".format(score, high_score), align="center", font=("Comic Sans", 32, "normal"))
    #Check for collision with food
    if head.distance(food) < 20:
        #Move the food to another spot
        x = random.randint(-350, 350)
        y = random.randint(-350, 350)
        food.goto(x,y)

        #Add a segment
        new_segment = turtle.Turtle()
        new_segment.speed(0)
        new_segment.shape("square")
        new_segment.color("green")
        new_segment.penup()
        segments.append(new_segment)

        delay -= 0.001

        #Increase Score
        score += 10

        if score > high_score:
            high_score = score

        
        pen.clear()
        pen.write("Score: {} High Score: {}".format(score, high_score), align="center", font=("Comic Sans", 32, "normal"))

    # Move the end segments first in reverse order
    for index in range(len(segments)-1, 0, -1):
        x = segments[index-1].xcor()
        y = segments[index-1].ycor()
        segments[index].goto(x, y)

    # Move segment 0 to where the head is
    if len(segments) > 0:
        x = head.xcor()
        y = head.ycor()
        segments[0].goto(x,y)
        

    move()

    #Check for body collisions (with head)
    for segment in segments:
        if segment.distance(head) < 20:
            time.sleep(1)
            head.goto(0,0)
            head.direction = "stop"
        
            # Hide the segments
            for segment in segments:
                segment.goto(1000, 1000)
        
            # Clear the segments list
            segments.clear()

            #Reset score
            score = 0

            #Reset Delay
            delay = 0.1

            #Update scoreboard
            pen.clear()
            pen.write("Score: {} High Score: {}".format(score, high_score), align="center", font=("Comic Sans", 32, "normal"))


    time.sleep(delay)

wnd.mainloop()
