import java.util.Arrays;

public class MergeSort{
     /*For merge sort, we are sorting a list/array of integers by taking that array or list
     and breaking it up into a smaller, temporary array(s) or list(s) in order to have less numbers
     to sort. From there, we sort the smaller temporary arrays and then merge them back together in the 
     original array or list.*/
     
     /*ILLUSTRATION: int arr[] { 8, 34, 32, 0, 2, 6, 4091 }
                    temp[]{8, 34, 32} = temp[]{8, 32, 34}
                    temp[]{0, 6, 2, 4091} = temp[]{0, 2, 6, 4091}
                    finished product:
                    Compare all the numbers in both temporary arrays and order them accordingly,
                    then copy them back over to the real array arr[]
                    8 > 0 yes
                    8 > 2 yes
                    8 > 6 yes
                    8 > 4091 no
                    8 goes in between 6 and 4091
                    
                    {0, 2, 6, 8, 4091}
                    
                    32 > 0 yes
                    32 > 2 yes
                    32 > 6 yes
                    32 > 8 yes
                    32 > 4091 no
                    
                    <0, 2, 6, 8, 32, 4091}
                    
                    repeat this until all numbers are ordered in the old array arr[].
                    */
     public static void merge(int numbers[], int start, int mid, int end){
         //Create a "middle ground" temporary array and initialize it as empty.
         int temp[] = new int[end - start + 1];
         
         //NEW CONCEPT: We can initialize the crawlers for our arrays right up here.
         //Say goodbye to for-loops
         int i = start;
         int j = mid + 1;
         int k = 0;
         //I and J in this case are the two variables that we are comparing to sort.
         //They are the two halves that are mentioned in the illustration
         //For the first while loop, it's all about placement and not value.
         //We're essentially setting our first while loop to say that while crawler i
         // is less than the mid-point, and while crawler j is less than the end, break
         //the values in the array up into a temporary arrays for sorting.
        while(i <= mid && j <= end){
             if(numbers[i] <= numbers[j]){
                 //Start sorting up front
                 temp[k] = numbers[i];
                 k++; 
                 i++;
             }
             //After we're done sorting, our crawler will go to the second half and set up
             //a temporary array there for sorting
             else{
                 temp[k] = numbers[j];
                 k++;
                 j++;
             }
             
         }
         //All this above simply sets up our temporary arrays for sorting and
         //does the job within those temporary arrays
         //-------------------------------------------------------
        //Copies the first half back into the original array
        while(i <= mid){
             temp[k] = numbers[i];
             k++; 
             i++;
        }
        //Copies the second half back into the original array
        while(j <= end){
            temp[k] = numbers[j];
            k++;
            j++;
        }
        //For loop that actually iterates through all this
        for(i = start; i <= end; i++){
            numbers[i] = temp[i - start];
        }
        
     }
     //This small class below just deals with recursing through sorting the first half,
     //then the second half, and finally merging the two together. 
    public static void mergeSort(int numbers[], int start, int end){
        if(start < end){
            int mid = (start + end) / 2;
            mergeSort(numbers, start, mid);
            mergeSort(numbers, mid + 1, end);
            merge(numbers, start, mid, end);
        }
    }
    //String arguments and our test statements
    public static void main(String []args){
        System.out.println("Given Array");
        int numbers[] = { 8, 32, 34, 0, 2, 6, 4091 };
        System.out.println(Arrays.toString(numbers));
        MergeSort ourSort = new MergeSort();
        ourSort.mergeSort(numbers, 0, numbers.length - 1);
        System.out.println("\n Finished Array: ");
        System.out.println(Arrays.toString(numbers));
        
        System.out.println("\n Next Given Array");
        int numbers1[] = { 321, 3, 341, 23, 2490, 6, 4091, 32, 33, 34, 35, 36, 37 };
        System.out.println(Arrays.toString(numbers1));
        MergeSort ourNewSort = new MergeSort();
        ourNewSort.mergeSort(numbers1, 0, numbers1.length - 1);
        System.out.println("\n Next Finished Array: ");
        System.out.println(Arrays.toString(numbers1));
        
        
     }
}