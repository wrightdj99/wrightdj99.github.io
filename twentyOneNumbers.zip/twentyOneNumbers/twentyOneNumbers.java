public class twentyOneNumbers{

     public static void main(String []args){
        System.out.println("Dan's First August Challenge");
        
        //Print up numbers normally
        for(int i = 0; i < 22; i++){
            if(i % 2 != 0){
                System.out.println(i);
            }
            
        }
     }
}


